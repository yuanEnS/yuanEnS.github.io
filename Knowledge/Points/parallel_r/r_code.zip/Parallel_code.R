library(parallel)

## make clusters
clnum <- detectCores() 
## clnum is the core numbers we prepare to use
## This way, we will use full cores of this machine,
## But in cluster, I will specified a little smaller than full.
## E.g. If I apply 64 cores, I will specify 56 in case of some errors I don't understand.

print(paste("detectCores: ",clnum))

cl <- makeCluster(getOption('cl.cores',clnum))
## This line is to make cluster as its name.


time_start <- Sys.time()
cyc_times <- 1600000


# 1. Parallel function --------------------
#### We need to put all in this function, specifically, mean_estimator function.
mean_esti <- function(seed){
  mean_estimator <- function(seed,mu){
    ## function of one experiment
    set.seed(seed)
    x = rnorm(1000,mean = mu,sd = 1)
    return (mean(x))
  }
  mu <- 20
  mean_estimate <- mean_estimator(seed,mu)
  return(mean_estimate)
  ### return is needed, and if we want many values saved, we can return a vector like c(a,b,c,d)
}

res <- parLapply(cl,1:cyc_times,mean_esti) 
### parLapply: running our function in cluster. So cool.
### cl: as specified, cluster. 1:cyc_times parameter of functions. mean_esti: our function.
### Whether can we specifiy multiple values one time, I haven't found any method.

time_end1 <- Sys.time()
mean_estimates_parallel <- NULL
print(time_end1 - time_start)
for(i in 1:length(res)){
  ## We still use for loop here.
  mean_estimates_parallel <- c(mean_estimates_parallel,res[[i]][1])
  #### res is a list type. So res[[i]], is the ith value, and is what we resturn.
}
time_end2 <- Sys.time()
print(time_end2 - time_start)
hist(mean_estimates_parallel)
save.image("Cluster results.RData")



