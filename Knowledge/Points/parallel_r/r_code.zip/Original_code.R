

# 1. Functions ------------------------------------------------------------

mean_estimator <- function(seed,mu){
  ## function of one experiment
  set.seed(seed)
  x = rnorm(1000,mean = mu,sd = 1)
  return (mean(x))
}


# 2. Experiments For loop----------------------------------------------------------
mu <- 20
mean_estimates <- NULL
cyc_times <- 1600000
time_start <- Sys.time()
for(seed in 1:cyc_times){
  # mean_estimator(seed,mu) ## experiment 2
  mean_estimates <- c(mean_estimates,mean_estimator(seed,mu)) ## experiment 1
}
time_end <- Sys.time()
print(time_end - time_start)
hist(mean_estimates)
save.image("For loop results.RData")

